"""
Validation helpers for SignalScout.

Keeping validation in one place makes it easy to see every rule the app
enforces, and keeps app.py / pipeline.py focused on orchestration.
"""
from typing import List, Dict, Tuple

MAX_PROSPECTS = 10

REQUIRED_PROSPECT_COLUMNS = [
    "Prospect ID", "Company", "Website", "Contact", "Job Title",
    "LinkedIn URL", "Trigger Evidence URL", "Trigger Evidence/Notes",
]


def validate_campaign_info(product: str, target_customer: str, geography: str) -> List[str]:
    """Return a list of human-readable error messages (empty = valid)."""
    errors = []
    if not product or not product.strip():
        errors.append("Product / Service is required.")
    if not target_customer or not target_customer.strip():
        errors.append("Target Customer is required.")
    if not geography or not geography.strip():
        errors.append("Target Geography is required.")
    return errors


def validate_csv_columns(columns: List[str]) -> List[str]:
    """Check that the uploaded CSV has the columns we need (case-insensitive)."""
    normalized = {c.strip().lower() for c in columns}
    errors = []
    for required in ["company"]:  # only Company is strictly required to exist as a column
        if required not in normalized:
            errors.append(f"Missing required column: '{required.title()}'.")
    return errors


def validate_prospect_row(row: Dict) -> Tuple[bool, str]:
    """A single prospect row is valid if it at least has a Company name."""
    company = (row.get("Company") or "").strip()
    if not company:
        return False, "Missing Company name."
    return True, ""


def validate_prospect_count(rows: List[Dict]) -> List[str]:
    errors = []
    if len(rows) == 0:
        errors.append("At least one prospect is required.")
    if len(rows) > MAX_PROSPECTS:
        errors.append(
            f"Too many prospects: {len(rows)} provided, maximum is {MAX_PROSPECTS}. "
            "Only the first 10 will be processed."
        )
    return errors


def validate_api_key(provider: str, openai_key: str, anthropic_key: str) -> List[str]:
    errors = []
    if provider == "OpenAI" and not openai_key:
        errors.append(
            "OpenAI selected but OPENAI_API_KEY is not set. Add it to your .env file "
            "or switch to Demo Mode."
        )
    if provider == "Anthropic" and not anthropic_key:
        errors.append(
            "Anthropic selected but ANTHROPIC_API_KEY is not set. Add it to your .env file "
            "or switch to Demo Mode."
        )
    return errors
