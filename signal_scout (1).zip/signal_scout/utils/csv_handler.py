"""
CSV input/output helpers for SignalScout.

Handles:
- Parsing an uploaded prospects CSV into normalized dict rows.
- Exporting processed results to CSV (Make.com / Tableau friendly) and JSON.
"""
import csv
import io
import json
from typing import List, Dict

# Column names as they should appear in the uploaded prospects CSV.
PROSPECT_INPUT_COLUMNS = [
    "Prospect ID", "Company", "Website", "Contact", "Job Title",
    "LinkedIn URL", "Trigger Evidence URL", "Trigger Evidence/Notes",
]

# Exact, stable column order for the final export CSV.
# Stability matters here: Make.com and Tableau scenarios map to these names.
EXPORT_COLUMNS = [
    "Prospect ID", "Company", "Website", "Contact", "Job Title",
    "LinkedIn URL", "Product/Service", "Target Customer", "Geography",
    "Signal Type", "Signal Evidence", "Signal Recency", "Signal Strength",
    "Signal Explanation", "Company Context", "Potential Business Problem",
    "Outreach Angle", "Why Angle Is Relevant", "Value Proposition",
    "Recommended CTA", "Email Subject", "Email Body", "LinkedIn Message",
    "Follow-up", "Approval Status", "Notes",
]


def _normalize_header(name: str) -> str:
    """Collapse a header to a loose canonical form for matching:
    lowercase, trimmed, internal whitespace collapsed, '/' and '_' treated as spaces.
    'company', ' Company ', 'COMPANY' and 'company ' should all match "Company".
    """
    name = (name or "").strip().lower()
    name = name.replace("/", " ").replace("_", " ")
    return " ".join(name.split())


# Precomputed lookup: normalized header -> canonical PROSPECT_INPUT_COLUMNS name.
# Includes a couple of common real-world variants (e.g. no slash in "Trigger Evidence Notes").
_CANONICAL_HEADER_MAP = {_normalize_header(c): c for c in PROSPECT_INPUT_COLUMNS}
_CANONICAL_HEADER_MAP[_normalize_header("Trigger Evidence Notes")] = "Trigger Evidence/Notes"
_CANONICAL_HEADER_MAP[_normalize_header("LinkedIn")] = "LinkedIn URL"


def parse_prospects_csv(file_obj) -> List[Dict]:
    """Parse an uploaded CSV file-like object into a list of dict rows.

    Column matching is case-insensitive and whitespace/punctuation-tolerant
    (e.g. "company", "Company ", "COMPANY" all map to "Company"), so a CSV
    that *looks* like it has the right columns is actually parsed the same
    way it's validated. Missing optional columns are filled with empty
    strings so downstream code never has to guess whether a key exists.
    """
    text = file_obj.read()
    if isinstance(text, bytes):
        text = text.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))

    rows = []
    for raw_row in reader:
        # Build a normalized-header -> value map for this row, then pull out
        # each canonical column by its normalized name instead of an exact
        # string match. This is what actually fixes the mismatch: before,
        # a header like "company" (lowercase) silently matched nothing.
        normalized_raw = {
            _normalize_header(k): (v or "").strip() for k, v in raw_row.items() if k is not None
        }
        row = {}
        for canonical_col in PROSPECT_INPUT_COLUMNS:
            norm_key = _normalize_header(canonical_col)
            row[canonical_col] = normalized_raw.get(norm_key, "")
        # Catch any additional known variants (e.g. "Trigger Evidence Notes" with no slash).
        for norm_variant, canonical_col in _CANONICAL_HEADER_MAP.items():
            if not row.get(canonical_col) and norm_variant in normalized_raw:
                row[canonical_col] = normalized_raw[norm_variant]
        rows.append(row)
    return rows


def prospects_to_template_rows(manual_rows: List[Dict]) -> List[Dict]:
    """Normalize manually-entered rows (e.g. from st.data_editor) to the same shape."""
    normalized = []
    for row in manual_rows:
        normalized.append({col: str(row.get(col) or "").strip() for col in PROSPECT_INPUT_COLUMNS})
    return normalized


def results_to_csv_bytes(results: List[Dict]) -> bytes:
    """Flatten pipeline results into the stable export CSV format."""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=EXPORT_COLUMNS)
    writer.writeheader()
    for r in results:
        writer.writerow({col: r.get(col, "") for col in EXPORT_COLUMNS})
    return output.getvalue().encode("utf-8")


def results_to_json_bytes(results: List[Dict]) -> bytes:
    return json.dumps(results, indent=2).encode("utf-8")


def make_blank_template_csv() -> str:
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=PROSPECT_INPUT_COLUMNS)
    writer.writeheader()
    writer.writerow({
        "Prospect ID": "1",
        "Company": "Acme Robotics",
        "Website": "https://acmerobotics.example.com",
        "Contact": "Jane Doe",
        "Job Title": "VP of Operations",
        "LinkedIn URL": "https://linkedin.com/in/janedoe-example",
        "Trigger Evidence URL": "https://acmerobotics.example.com/news/series-b",
        "Trigger Evidence/Notes": "Announced $12M Series B funding round on their blog, Sept 2026.",
    })
    return output.getvalue()
