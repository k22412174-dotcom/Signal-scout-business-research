"""
SignalScout — AI-Assisted Signal-Led Outreach Research

A local, beginner-friendly Streamlit app that helps you research B2B
prospects for a *verified* buying signal, then drafts outreach copy for
YOU to review, edit, and approve. It never sends anything automatically.

Run with: streamlit run app.py
"""
import os
import json
from datetime import datetime

import streamlit as st
from dotenv import load_dotenv

from utils.validators import (
    validate_campaign_info, validate_csv_columns, validate_prospect_count,
    validate_api_key, MAX_PROSPECTS,
)
from utils.csv_handler import (
    parse_prospects_csv, prospects_to_template_rows, results_to_csv_bytes,
    results_to_json_bytes, PROSPECT_INPUT_COLUMNS,
)
from core.pipeline import run_pipeline

load_dotenv()  # reads .env if present; never overwrites real environment variables

st.set_page_config(page_title="SignalScout", page_icon="📡", layout="wide")

# ---------------------------------------------------------------------------
# Session state setup
# ---------------------------------------------------------------------------
if "results" not in st.session_state:
    st.session_state.results = []  # list of result dicts from the pipeline
if "prospects" not in st.session_state:
    st.session_state.prospects = []  # list of input prospect dicts
if "last_run_provider" not in st.session_state:
    st.session_state.last_run_provider = None

BADGE_COLORS = {
    "Strong": "🟢", "Moderate": "🟡", "Weak": "🟠", "No verified signal": "⚪",
    "PENDING": "⏳", "APPROVED": "✅", "REJECTED": "❌", "EDIT REQUIRED": "✏️",
    "SUCCESS": "✅", "PARTIAL": "⚠️", "FAILED": "❌",
}


def badge(value: str) -> str:
    icon = BADGE_COLORS.get(value, "•")
    return f"{icon} {value}"


def _peek_columns(uploaded_file):
    """Read just the header row of an uploaded CSV without consuming it."""
    try:
        uploaded_file.seek(0)
        first_line = uploaded_file.readline()
        uploaded_file.seek(0)
        if isinstance(first_line, bytes):
            first_line = first_line.decode("utf-8-sig", errors="replace")
        return [c.strip() for c in first_line.strip().split(",")]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
st.title("📡 SignalScout")
st.caption("AI-Assisted Signal-Led Outreach Research")

# ---------------------------------------------------------------------------
# Sidebar — Campaign Setup
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("Campaign Setup")
    product = st.text_input("Product / Service", key="product",
                             placeholder="e.g. Warehouse scheduling software")
    target_customer = st.text_input("Target Customer", key="target_customer",
                                     placeholder="e.g. Ops leaders at mid-size 3PLs")
    geography = st.text_input("Target Geography", key="geography",
                               placeholder="e.g. United States")

    st.markdown("---")
    st.subheader("AI Provider")
    provider = st.selectbox(
        "AI Provider", ["Demo Mode", "OpenAI", "Anthropic"], index=0,
        help="Demo Mode works fully offline with no API key. OpenAI/Anthropic "
             "require the matching API key in your .env file.",
    )

    openai_key = os.getenv("OPENAI_API_KEY", "")
    anthropic_key = os.getenv("ANTHROPIC_API_KEY", "")

    if provider == "Demo Mode":
        st.info("🧪 **DEMO MODE — AI API not connected**\n\n"
                 "Responses below are deterministic mock output, not from any AI model.")
    elif provider == "OpenAI":
        if openai_key:
            st.success("OpenAI API key detected.")
        else:
            st.warning("OPENAI_API_KEY not found in your .env file. Add it, or use Demo Mode.")
    elif provider == "Anthropic":
        if anthropic_key:
            st.success("Anthropic API key detected.")
        else:
            st.warning("ANTHROPIC_API_KEY not found in your .env file. Add it, or use Demo Mode.")

    st.markdown("---")
    st.caption("SignalScout never sends outreach automatically. All copy requires your "
               "manual review and approval before use.")

campaign = {"product": product, "target_customer": target_customer, "geography": geography}

# ---------------------------------------------------------------------------
# Section: Prospect Input
# ---------------------------------------------------------------------------
st.header("1️⃣ Prospect Input")
st.caption(f"Add up to {MAX_PROSPECTS} prospects, either manually or via CSV upload.")

input_mode = st.radio("Input method", ["Manual entry", "Upload CSV"], horizontal=True)

prospects_input = []

if input_mode == "Manual entry":
    st.write("Edit the table below (double-click a cell to edit). Leave unused rows blank.")
    default_rows = [{col: "" for col in PROSPECT_INPUT_COLUMNS} for _ in range(3)]
    for i, row in enumerate(default_rows):
        row["Prospect ID"] = str(i + 1)
    edited = st.data_editor(
        default_rows, num_rows="dynamic", use_container_width=True, key="manual_table",
        column_config={
            "Trigger Evidence/Notes": st.column_config.TextColumn(width="large"),
        },
    )
    prospects_input = prospects_to_template_rows(edited)
else:
    st.download_button(
        "⬇️ Download blank CSV template",
        data=open("data/prospects_template.csv", "rb").read(),
        file_name="prospects_template.csv", mime="text/csv",
    )
    uploaded = st.file_uploader("Upload prospects CSV", type=["csv"])
    if uploaded is not None:
        col_errors = validate_csv_columns(_peek_columns(uploaded))
        if col_errors:
            for e in col_errors:
                st.error(e)
        else:
            uploaded.seek(0)
            prospects_input = parse_prospects_csv(uploaded)

# Drop fully-blank rows (common with manual entry / dynamic tables)
prospects_input = [p for p in prospects_input if any(v.strip() for v in p.values())]

count_errors = validate_prospect_count(prospects_input) if prospects_input else []
if len(prospects_input) > MAX_PROSPECTS:
    st.warning(f"You entered {len(prospects_input)} prospects — only the first "
               f"{MAX_PROSPECTS} will be processed.")
    prospects_input = prospects_input[:MAX_PROSPECTS]

if prospects_input:
    invalid_rows = [p.get("Company", "(blank)") for p in prospects_input if not p.get("Company", "").strip()]
    if invalid_rows:
        st.error(f"{len(invalid_rows)} row(s) are missing a Company name and will be skipped.")
    st.success(f"{len(prospects_input)} prospect row(s) loaded.")

st.session_state.prospects = prospects_input

# ---------------------------------------------------------------------------
# Section: Research & Analysis
# ---------------------------------------------------------------------------
st.header("2️⃣ Research & Analysis")

campaign_errors = validate_campaign_info(product, target_customer, geography)
api_errors = validate_api_key(provider, openai_key, anthropic_key)

if campaign_errors:
    for e in campaign_errors:
        st.warning(e)
if api_errors:
    for e in api_errors:
        st.warning(e)

run_disabled = bool(campaign_errors) or bool(api_errors) or not prospects_input

if st.button("▶️ Run Analysis", type="primary", disabled=run_disabled):
    progress_bar = st.progress(0, text="Starting...")
    status_area = st.empty()

    def _progress(i, total, company):
        progress_bar.progress(i / total, text=f"Processing {i}/{total}: {company}")

    with st.spinner("Running SignalScout pipeline..."):
        results = run_pipeline(prospects_input, campaign, provider, progress_callback=_progress)

    st.session_state.results = results
    st.session_state.last_run_provider = provider
    progress_bar.progress(1.0, text="Done.")
    st.success(f"Processed {len(results)} prospect(s).")

if run_disabled and not prospects_input:
    st.caption("Add at least one prospect above to enable analysis.")

# ---------------------------------------------------------------------------
# Section: Results + Approval
# ---------------------------------------------------------------------------
if st.session_state.results:
    st.header("3️⃣ Results & Approval")
    if st.session_state.last_run_provider == "Demo Mode":
        st.info("🧪 **DEMO MODE — AI API not connected.** All research and copy below is "
                 "deterministic mock output for demonstration purposes only.")

    for idx, result in enumerate(st.session_state.results):
        company = result.get("Company") or "(unknown company)"
        signal_strength = result.get("Signal Strength", "No verified signal")
        approval = result.get("Approval Status", "PENDING")
        proc_status = result.get("Processing Status", "")

        header = f"{badge(signal_strength)} — **{company}** — {badge(approval)}"
        if proc_status == "FAILED":
            header += "  ⚠️ *processing failed*"

        with st.expander(header, expanded=False):
            if result.get("Processing Error"):
                st.error(f"Processing note: {result['Processing Error']}")

            c1, c2 = st.columns(2)
            with c1:
                st.markdown(f"**Website:** {result.get('Website') or '—'}")
                st.markdown(f"**Contact:** {result.get('Contact') or '—'}")
                st.markdown(f"**Job Title:** {result.get('Job Title') or '—'}")
                st.markdown(f"**Signal Type:** {result.get('Signal Type')}")
                st.markdown(f"**Signal Strength:** {badge(signal_strength)}")
                st.markdown(f"**Signal Evidence:** {result.get('Signal Evidence') or '—'}")
            with c2:
                st.markdown(f"**Company Context:** {result.get('Company Context') or '—'}")
                st.markdown(f"**Potential Business Problem:** {result.get('Potential Business Problem') or '—'}")
                st.markdown(f"**Outreach Angle:** {result.get('Outreach Angle') or '—'}")
                st.markdown(f"**Value Proposition:** {result.get('Value Proposition') or '—'}")
                st.markdown(f"**Recommended CTA:** {result.get('Recommended CTA') or '—'}")

            st.markdown("---")
            st.markdown("**✏️ Edit outreach copy before approving:**")

            new_subject = st.text_input("Email Subject", value=result.get("Email Subject", ""),
                                         key=f"subj_{idx}")
            new_body = st.text_area("Email Body", value=result.get("Email Body", ""),
                                     key=f"body_{idx}", height=150)
            new_linkedin = st.text_area("LinkedIn Message", value=result.get("LinkedIn Message", ""),
                                         key=f"li_{idx}", height=100)
            new_followup = st.text_area("Follow-up", value=result.get("Follow-up", ""),
                                         key=f"fu_{idx}", height=100)
            new_notes = st.text_input("Notes", value=result.get("Notes", ""), key=f"notes_{idx}")

            new_status = st.selectbox(
                "Approval Status", ["PENDING", "APPROVED", "REJECTED", "EDIT REQUIRED"],
                index=["PENDING", "APPROVED", "REJECTED", "EDIT REQUIRED"].index(approval),
                key=f"status_{idx}",
            )

            # Persist edits back into session state immediately.
            result["Email Subject"] = new_subject
            result["Email Body"] = new_body
            result["LinkedIn Message"] = new_linkedin
            result["Follow-up"] = new_followup
            result["Notes"] = new_notes
            result["Approval Status"] = new_status

    # -----------------------------------------------------------------
    # Section: Export
    # -----------------------------------------------------------------
    st.header("4️⃣ Export")
    st.caption("Nothing is sent automatically. Export CSV/JSON and use it in your own "
               "email tool, Make.com scenario, or Tableau workbook.")

    exportable = [{k: v for k, v in r.items() if k != "_raw"} for r in st.session_state.results]
    approved_only = [r for r in exportable if r.get("Approval Status") == "APPROVED"]

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    e1, e2, e3 = st.columns(3)
    with e1:
        st.download_button(
            "📤 Export All Results (CSV)",
            data=results_to_csv_bytes(exportable),
            file_name=f"signalscout_all_{ts}.csv", mime="text/csv",
            use_container_width=True,
        )
    with e2:
        st.download_button(
            "✅ Export Approved Only (CSV)",
            data=results_to_csv_bytes(approved_only) if approved_only else b"",
            file_name=f"signalscout_approved_{ts}.csv", mime="text/csv",
            disabled=not approved_only, use_container_width=True,
        )
    with e3:
        st.download_button(
            "🗂️ Download JSON (full results)",
            data=results_to_json_bytes(exportable),
            file_name=f"signalscout_results_{ts}.json", mime="application/json",
            use_container_width=True,
        )
else:
    st.caption("Run analysis above to see results here.")
