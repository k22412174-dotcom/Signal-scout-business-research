"""
Thin, provider-agnostic AI client for SignalScout.

Each pipeline stage builds a prompt and calls `call_ai(...)`, which:
  - Returns a deterministic demo response when provider == "Demo Mode"
    (no network / API key required).
  - Otherwise calls OpenAI or Anthropic and parses the JSON response.

Keeping this in one module means adding a new provider later only touches
one file, and the four stage modules never need to know provider details.
"""
import os
import json
import re
from typing import Callable, Dict


class AIClientError(Exception):
    """Raised when an AI call fails or returns unparseable output."""
    pass


def _strip_json_fences(text: str) -> str:
    """AI models sometimes wrap JSON in ```json ... ``` fences. Strip them."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _extract_json(text: str) -> Dict:
    cleaned = _strip_json_fences(text)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Last resort: grab the outermost {...} block.
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass
        raise AIClientError(f"Could not parse AI response as JSON: {text[:300]}")


def _call_openai(system_prompt: str, user_prompt: str) -> str:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise AIClientError("OPENAI_API_KEY is not set.")
    try:
        from openai import OpenAI
    except ImportError:
        raise AIClientError("The 'openai' package is not installed. Run: pip install openai")

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.4,
    )
    return response.choices[0].message.content or ""


def _call_anthropic(system_prompt: str, user_prompt: str) -> str:
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise AIClientError("ANTHROPIC_API_KEY is not set.")
    try:
        import anthropic
    except ImportError:
        raise AIClientError("The 'anthropic' package is not installed. Run: pip install anthropic")

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )
    parts = [block.text for block in response.content if getattr(block, "type", None) == "text"]
    return "".join(parts)


def call_ai(
    provider: str,
    system_prompt: str,
    user_prompt: str,
    demo_response_fn: Callable[[], Dict],
) -> Dict:
    """Route to the selected provider and return a parsed dict.

    Raises AIClientError on any failure so callers (pipeline.py) can catch
    it and mark that single prospect/stage as failed without crashing the
    whole run.
    """
    if provider == "Demo Mode":
        return demo_response_fn()

    if provider == "OpenAI":
        raw = _call_openai(system_prompt, user_prompt)
    elif provider == "Anthropic":
        raw = _call_anthropic(system_prompt, user_prompt)
    else:
        raise AIClientError(f"Unknown AI provider: {provider}")

    return _extract_json(raw)
