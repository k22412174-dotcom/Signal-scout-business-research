"""
Stage 1: Signal Analyzer.

Determines whether there is a real, evidence-backed buying signal for a
prospect. Never invents a signal — if evidence is thin, it reports
"No verified signal" and explains what's missing.
"""
import os
from typing import Dict
from core.ai_client import call_ai, AIClientError

_PROMPT_PATH = os.path.join(os.path.dirname(__file__), "..", "prompts", "signal_analyzer.txt")

REQUIRED_KEYS = [
    "signal_type", "signal_evidence", "signal_recency",
    "signal_strength", "why_signal_matters", "evidence_limitations",
]


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r", encoding="utf-8") as f:
        return f.read()


def _demo_response(prospect: Dict, campaign: Dict) -> Dict:
    """Deterministic mock response based purely on the supplied prospect data.

    No network call, no invention beyond what's in trigger evidence notes.
    """
    notes = (prospect.get("Trigger Evidence/Notes") or "").strip()
    url = (prospect.get("Trigger Evidence URL") or "").strip()

    if not notes and not url:
        return {
            "signal_type": "No verified signal",
            "signal_evidence": "",
            "signal_recency": "Unknown",
            "signal_strength": "No verified signal",
            "why_signal_matters": "",
            "evidence_limitations": (
                "[DEMO MODE] No trigger evidence URL or notes were supplied for this "
                "prospect, so no signal can be verified. Add evidence to generate a "
                "real signal classification."
            ),
        }

    lowered = notes.lower()
    keyword_map = [
        (["hiring", "job posting", "we're hiring", "open role"], "Hiring"),
        (["funding", "series a", "series b", "series c", "raised $", "investment"], "Funding"),
        (["launch", "new product", "released"], "Product launch"),
        (["expansion", "expanding", "new office", "opening in"], "Expansion"),
        (["new location", "opened a location", "new site"], "New location"),
        (["ceo", "cfo", "cto", "new hire", "appointed", "promoted"], "Leadership change"),
        (["partnership", "partnered", "alliance"], "Partnership"),
        (["migrated", "adopted", "implemented", "switched to"], "Technology change"),
        (["campaign", "rebrand", "marketing push"], "Marketing activity"),
    ]
    signal_type = "Other"
    for keywords, label in keyword_map:
        if any(k in lowered for k in keywords):
            signal_type = label
            break

    strength = "Moderate" if url else "Weak"
    if len(notes) > 60 and url:
        strength = "Strong"

    return {
        "signal_type": signal_type,
        "signal_evidence": f"[DEMO MODE] Based on supplied notes: \"{notes}\"" + (f" (source: {url})" if url else ""),
        "signal_recency": "Unknown — recency not verifiable in Demo Mode",
        "signal_strength": strength,
        "why_signal_matters": (
            f"[DEMO MODE] A '{signal_type.lower()}' event can indicate changing needs at "
            f"{prospect.get('Company', 'this company')} that may align with "
            f"'{campaign.get('product', 'your offering')}'."
        ),
        "evidence_limitations": (
            "[DEMO MODE] This is a deterministic mock classification derived only from the "
            "text you provided. It has not been verified against a live source."
        ),
    }


def analyze(prospect: Dict, campaign: Dict, provider: str) -> Dict:
    """Run signal analysis for one prospect. Returns dict with REQUIRED_KEYS,
    plus '_error' set to a message string if something went wrong.
    """
    def demo():
        return _demo_response(prospect, campaign)

    try:
        if provider == "Demo Mode":
            result = demo()
        else:
            prompt_template = _load_prompt()
            filled = prompt_template.format(
                product=campaign.get("product", ""),
                target_customer=campaign.get("target_customer", ""),
                geography=campaign.get("geography", ""),
                company=prospect.get("Company", ""),
                website=prospect.get("Website", ""),
                contact=prospect.get("Contact", ""),
                job_title=prospect.get("Job Title", ""),
                trigger_url=prospect.get("Trigger Evidence URL", ""),
                trigger_notes=prospect.get("Trigger Evidence/Notes", ""),
            )
            system_prompt = (
                "You are a careful B2B research analyst. Never invent facts. "
                "Respond with valid JSON only."
            )
            result = call_ai(provider, system_prompt, filled, demo)

        for key in REQUIRED_KEYS:
            result.setdefault(key, "")
        return result
    except AIClientError as e:
        return {**{k: "" for k in REQUIRED_KEYS}, "signal_type": "No verified signal",
                "signal_strength": "No verified signal", "_error": str(e)}
    except Exception as e:  # noqa: BLE001 - never let one prospect crash the whole run
        return {**{k: "" for k in REQUIRED_KEYS}, "signal_type": "No verified signal",
                "signal_strength": "No verified signal", "_error": f"Unexpected error: {e}"}
