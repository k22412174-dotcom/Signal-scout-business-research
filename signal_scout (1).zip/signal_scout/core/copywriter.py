"""
Stage 4: Personalized Copywriter.

Writes email, LinkedIn, and follow-up copy. Never fabricates statistics,
facts, a prior relationship, or a contact name. If outreach isn't
recommended yet, the copy reflects that honestly instead of pretending.
"""
import os
from typing import Dict
from core.ai_client import call_ai, AIClientError

_PROMPT_PATH = os.path.join(os.path.dirname(__file__), "..", "prompts", "copywriter.txt")

REQUIRED_KEYS = ["email_subject", "email_body", "linkedin_message", "follow_up"]


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r", encoding="utf-8") as f:
        return f.read()


def _greeting(contact: str) -> str:
    return f"Hi {contact.split()[0]}," if contact.strip() else "Hi there,"


def _demo_response(prospect: Dict, campaign: Dict, signal: Dict, strategy: Dict) -> Dict:
    company = prospect.get("Company", "your company")
    contact = prospect.get("Contact", "")
    greeting = _greeting(contact)
    product = campaign.get("product", "our product")

    if strategy.get("outreach_angle") == "Do not contact yet":
        subject = f"Holding off on outreach to {company} — no verified signal"
        body = (
            f"{greeting}\n\n"
            f"[DEMO MODE] No outreach copy generated — there is no verified signal to "
            f"reference for {company} yet, so this run does not recommend contacting "
            f"this prospect. Add stronger trigger evidence and re-run to generate copy.\n\n"
            f"(Not sent — for review only.)"
        )
        return {
            "email_subject": subject,
            "email_body": body,
            "linkedin_message": "[DEMO MODE] Not recommended yet — no verified signal.",
            "follow_up": "[DEMO MODE] N/A until a verified signal is available.",
        }

    signal_type = signal.get("signal_type", "recent update")
    subject = f"Quick note on {company}'s {signal_type.lower()}"
    body = (
        f"{greeting}\n\n"
        f"[DEMO MODE] I noticed {company}'s recent {signal_type.lower()} "
        f"(per the evidence you supplied). We work on {product} for "
        f"{campaign.get('target_customer', 'teams like yours')}, and it seemed worth a "
        f"quick, no-pressure note.\n\n"
        f"Open to a short conversation if it's useful — no worries if not.\n\n"
        f"(This is placeholder demo copy, not sent to anyone.)"
    )
    linkedin = (
        f"[DEMO MODE] {greeting} Saw {company}'s {signal_type.lower()} — thought "
        f"{product} might be relevant. Open to connecting if useful, no pressure."
    )
    follow_up = (
        f"[DEMO MODE] Following up in case my last note got buried — happy to share "
        f"more or leave it here, whichever is useful."
    )

    return {
        "email_subject": subject,
        "email_body": body,
        "linkedin_message": linkedin,
        "follow_up": follow_up,
    }


def write(prospect: Dict, campaign: Dict, signal: Dict, strategy: Dict, provider: str) -> Dict:
    def demo():
        return _demo_response(prospect, campaign, signal, strategy)

    try:
        if provider == "Demo Mode":
            result = demo()
        else:
            prompt_template = _load_prompt()
            filled = prompt_template.format(
                product=campaign.get("product", ""),
                target_customer=campaign.get("target_customer", ""),
                company=prospect.get("Company", ""),
                contact=prospect.get("Contact", ""),
                job_title=prospect.get("Job Title", ""),
                signal_type=signal.get("signal_type", ""),
                signal_evidence=signal.get("signal_evidence", ""),
                outreach_angle=strategy.get("outreach_angle", ""),
                value_proposition=strategy.get("value_proposition", ""),
                recommended_cta=strategy.get("recommended_cta", ""),
            )
            system_prompt = (
                "You are a disciplined, honest B2B copywriter who never fabricates facts, "
                "statistics, or relationships. Respond with valid JSON only."
            )
            result = call_ai(provider, system_prompt, filled, demo)

        for key in REQUIRED_KEYS:
            result.setdefault(key, "")
        return result
    except AIClientError as e:
        return {**{k: "" for k in REQUIRED_KEYS}, "_error": str(e)}
    except Exception as e:  # noqa: BLE001
        return {**{k: "" for k in REQUIRED_KEYS}, "_error": f"Unexpected error: {e}"}
