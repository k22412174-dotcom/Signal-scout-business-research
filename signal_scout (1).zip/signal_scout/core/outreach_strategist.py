"""
Stage 3: Outreach Strategist.

Recommends an outreach angle grounded in the signal + company context.
If there's no meaningful signal, it recommends "Do not contact yet" rather
than inventing a justification.
"""
import os
from typing import Dict
from core.ai_client import call_ai, AIClientError

_PROMPT_PATH = os.path.join(os.path.dirname(__file__), "..", "prompts", "outreach_strategist.txt")

REQUIRED_KEYS = [
    "outreach_angle", "reason_angle_is_relevant", "potential_problem_or_opportunity",
    "value_proposition", "recommended_cta",
]


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r", encoding="utf-8") as f:
        return f.read()


def _demo_response(campaign: Dict, signal: Dict, context: Dict) -> Dict:
    signal_type = signal.get("signal_type", "No verified signal")
    signal_strength = signal.get("signal_strength", "No verified signal")
    product = campaign.get("product", "your offering")

    if signal_type == "No verified signal" or signal_strength in ("No verified signal", "Weak"):
        return {
            "outreach_angle": "Do not contact yet",
            "reason_angle_is_relevant": (
                "[DEMO MODE] There is no strong, verified signal to justify a personalized "
                "outreach angle. Reaching out now would require inventing a reason."
            ),
            "potential_problem_or_opportunity": "Unknown — insufficient evidence.",
            "value_proposition": "N/A until a verified signal is available.",
            "recommended_cta": "None — gather more evidence before contacting.",
        }

    return {
        "outreach_angle": f"Reference the recent {signal_type.lower()} event",
        "reason_angle_is_relevant": (
            f"[DEMO MODE] This is the only verified, timely reason to reach out right now."
        ),
        "potential_problem_or_opportunity": context.get(
            "potential_business_problem", "Unknown"
        ),
        "value_proposition": (
            f"[DEMO MODE] {product} may help address needs that typically follow a "
            f"'{signal_type.lower()}' event — framed as a hypothesis, not a guarantee."
        ),
        "recommended_cta": "Ask a low-pressure question or offer a short, optional call.",
    }


def analyze(campaign: Dict, signal: Dict, context: Dict, provider: str) -> Dict:
    def demo():
        return _demo_response(campaign, signal, context)

    try:
        if provider == "Demo Mode":
            result = demo()
        else:
            prompt_template = _load_prompt()
            filled = prompt_template.format(
                product=campaign.get("product", ""),
                target_customer=campaign.get("target_customer", ""),
                geography=campaign.get("geography", ""),
                signal_type=signal.get("signal_type", ""),
                signal_strength=signal.get("signal_strength", ""),
                signal_evidence=signal.get("signal_evidence", ""),
                company_summary=context.get("company_summary", ""),
                potential_business_problem=context.get("potential_business_problem", ""),
                potential_relevance=context.get("potential_relevance", ""),
            )
            system_prompt = (
                "You are a disciplined B2B outreach strategist who refuses to invent "
                "justifications for outreach. Respond with valid JSON only."
            )
            result = call_ai(provider, system_prompt, filled, demo)

        for key in REQUIRED_KEYS:
            result.setdefault(key, "")
        return result
    except AIClientError as e:
        return {**{k: "" for k in REQUIRED_KEYS}, "outreach_angle": "Do not contact yet", "_error": str(e)}
    except Exception as e:  # noqa: BLE001
        return {**{k: "" for k in REQUIRED_KEYS}, "outreach_angle": "Do not contact yet", "_error": f"Unexpected error: {e}"}
