"""
Pipeline orchestrator for SignalScout.

Runs each prospect through: Signal Analysis -> Company Context ->
Outreach Strategy -> Personalized Copy. One failing prospect never crashes
the whole run — it's marked Processing Status = FAILED with the error
preserved, and the run continues with the rest.
"""
import traceback
from typing import Dict, List, Callable, Optional

from core import signal_analyzer, context_analyzer, outreach_strategist, copywriter
from utils.validators import validate_prospect_row


def process_prospect(prospect: Dict, campaign: Dict, provider: str) -> Dict:
    """Run all four stages for a single prospect. Always returns a dict —
    never raises — so the caller can safely process the rest of the batch.
    """
    valid, reason = validate_prospect_row(prospect)
    if not valid:
        return _build_failed_result(prospect, campaign, f"Skipped: {reason}")

    try:
        signal = signal_analyzer.analyze(prospect, campaign, provider)
        context = context_analyzer.analyze(prospect, campaign, signal, provider)
        strategy = outreach_strategist.analyze(campaign, signal, context, provider)
        copy = copywriter.write(prospect, campaign, signal, strategy, provider)

        stages = (signal, context, strategy, copy)
        errors = [stage.get("_error") for stage in stages if stage.get("_error")]
        # FAILED = every single stage errored (nothing usable came back at all).
        # PARTIAL = some stages errored but others produced usable output.
        # SUCCESS = no stage errored (this is the only path in Demo Mode,
        # since demo responses never raise).
        if len(errors) == len(stages):
            processing_status = "FAILED"
        elif errors:
            processing_status = "PARTIAL"
        else:
            processing_status = "SUCCESS"

        return {
            "Prospect ID": prospect.get("Prospect ID", ""),
            "Company": prospect.get("Company", ""),
            "Website": prospect.get("Website", ""),
            "Contact": prospect.get("Contact", ""),
            "Job Title": prospect.get("Job Title", ""),
            "LinkedIn URL": prospect.get("LinkedIn URL", ""),
            "Product/Service": campaign.get("product", ""),
            "Target Customer": campaign.get("target_customer", ""),
            "Geography": campaign.get("geography", ""),
            "Signal Type": signal.get("signal_type", ""),
            "Signal Evidence": signal.get("signal_evidence", ""),
            "Signal Recency": signal.get("signal_recency", ""),
            "Signal Strength": signal.get("signal_strength", ""),
            "Signal Explanation": signal.get("why_signal_matters", "")
                or signal.get("evidence_limitations", ""),
            "Company Context": context.get("company_summary", ""),
            "Potential Business Problem": context.get("potential_business_problem", ""),
            "Outreach Angle": strategy.get("outreach_angle", ""),
            "Why Angle Is Relevant": strategy.get("reason_angle_is_relevant", ""),
            "Value Proposition": strategy.get("value_proposition", ""),
            "Recommended CTA": strategy.get("recommended_cta", ""),
            "Email Subject": copy.get("email_subject", ""),
            "Email Body": copy.get("email_body", ""),
            "LinkedIn Message": copy.get("linkedin_message", ""),
            "Follow-up": copy.get("follow_up", ""),
            "Approval Status": "PENDING",
            "Notes": "",
            "Processing Status": processing_status,
            "Processing Error": "; ".join(errors) if errors else "",
            "_raw": {
                "signal": signal, "context": context, "strategy": strategy, "copy": copy,
            },
        }
    except Exception as e:  # noqa: BLE001 - guarantee one bad prospect never kills the run
        # Capture the real traceback (not just str(e)) so a failure is
        # actually debuggable instead of collapsing to a vague message.
        detail = traceback.format_exc(limit=5)
        return _build_failed_result(
            prospect, campaign, f"Unexpected pipeline error: {e}\n{detail}"
        )


def _build_failed_result(prospect: Dict, campaign: Dict, error_msg: str) -> Dict:
    return {
        "Prospect ID": prospect.get("Prospect ID", ""),
        "Company": prospect.get("Company", ""),
        "Website": prospect.get("Website", ""),
        "Contact": prospect.get("Contact", ""),
        "Job Title": prospect.get("Job Title", ""),
        "LinkedIn URL": prospect.get("LinkedIn URL", ""),
        "Product/Service": campaign.get("product", ""),
        "Target Customer": campaign.get("target_customer", ""),
        "Geography": campaign.get("geography", ""),
        "Signal Type": "No verified signal",
        "Signal Evidence": "",
        "Signal Recency": "",
        "Signal Strength": "No verified signal",
        "Signal Explanation": "",
        "Company Context": "",
        "Potential Business Problem": "",
        "Outreach Angle": "Do not contact yet",
        "Why Angle Is Relevant": "",
        "Value Proposition": "",
        "Recommended CTA": "",
        "Email Subject": "",
        "Email Body": "",
        "LinkedIn Message": "",
        "Follow-up": "",
        "Approval Status": "PENDING",
        "Notes": "",
        "Processing Status": "FAILED",
        "Processing Error": error_msg,
        "_raw": {},
    }


def run_pipeline(
    prospects: List[Dict],
    campaign: Dict,
    provider: str,
    progress_callback: Optional[Callable[[int, int, str], None]] = None,
) -> List[Dict]:
    """Process every prospect, calling progress_callback(index, total, company)
    after each one so the UI can show a progress bar.
    """
    results = []
    total = len(prospects)
    for i, prospect in enumerate(prospects):
        result = process_prospect(prospect, campaign, provider)
        results.append(result)
        if progress_callback:
            progress_callback(i + 1, total, prospect.get("Company", "(unknown)"))
    return results
