"""
Stage 2: Company Context Analyzer.

Builds a short, honest context summary for the prospect's company, keeping
facts and hypotheses clearly separated. Never invents company facts.
"""
import os
from typing import Dict
from core.ai_client import call_ai, AIClientError

_PROMPT_PATH = os.path.join(os.path.dirname(__file__), "..", "prompts", "context_analyzer.txt")

REQUIRED_KEYS = [
    "company_summary", "relevant_context", "potential_business_problem",
    "potential_relevance", "uncertainties",
]


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r", encoding="utf-8") as f:
        return f.read()


def _demo_response(prospect: Dict, campaign: Dict, signal: Dict) -> Dict:
    company = prospect.get("Company", "This company")
    website = prospect.get("Website", "")
    signal_type = signal.get("signal_type", "No verified signal")

    if signal_type == "No verified signal":
        return {
            "company_summary": (
                f"[DEMO MODE] {company} — no verified public information was supplied "
                f"beyond the company name{' and website ' + website if website else ''}."
            ),
            "relevant_context": "[DEMO MODE] No additional context available without evidence.",
            "potential_business_problem": "Unknown — insufficient evidence to hypothesize responsibly.",
            "potential_relevance": "Unknown",
            "uncertainties": (
                "[DEMO MODE] Everything about this company beyond its name/website is "
                "unverified. Do not proceed to outreach without more evidence."
            ),
        }

    return {
        "company_summary": (
            f"[DEMO MODE] {company} recently had a '{signal_type.lower()}' event "
            f"(per supplied evidence). No other company facts are verified in Demo Mode."
        ),
        "relevant_context": (
            f"[DEMO MODE] The '{signal_type.lower()}' signal is the only verified context "
            f"available for {company}."
        ),
        "potential_business_problem": (
            f"[HYPOTHESIS — DEMO MODE] Companies going through a '{signal_type.lower()}' "
            f"event often face related operational changes — this is a guess, not a fact."
        ),
        "potential_relevance": (
            f"[HYPOTHESIS — DEMO MODE] '{campaign.get('product', 'Your offering')}' may be "
            f"relevant if {company}'s needs shifted because of this event."
        ),
        "uncertainties": (
            "[DEMO MODE] Business problem and relevance above are hypotheses inferred from "
            "the signal only, not confirmed facts about the company."
        ),
    }


def analyze(prospect: Dict, campaign: Dict, signal: Dict, provider: str) -> Dict:
    def demo():
        return _demo_response(prospect, campaign, signal)

    try:
        if provider == "Demo Mode":
            result = demo()
        else:
            prompt_template = _load_prompt()
            filled = prompt_template.format(
                product=campaign.get("product", ""),
                target_customer=campaign.get("target_customer", ""),
                geography=campaign.get("geography", ""),
                company=prospect.get("Company", ""),
                website=prospect.get("Website", ""),
                signal_type=signal.get("signal_type", ""),
                signal_evidence=signal.get("signal_evidence", ""),
                signal_strength=signal.get("signal_strength", ""),
            )
            system_prompt = (
                "You are a careful B2B research analyst. Never invent company facts. "
                "Respond with valid JSON only."
            )
            result = call_ai(provider, system_prompt, filled, demo)

        for key in REQUIRED_KEYS:
            result.setdefault(key, "")
        return result
    except AIClientError as e:
        return {**{k: "" for k in REQUIRED_KEYS}, "_error": str(e)}
    except Exception as e:  # noqa: BLE001
        return {**{k: "" for k in REQUIRED_KEYS}, "_error": f"Unexpected error: {e}"}
