# 📡 SignalScout

**AI-Assisted Signal-Led Outreach Research** — a local, beginner-friendly tool
for researching B2B prospects and drafting outreach copy for you to review.

> ⚠️ **SignalScout never contacts anyone automatically.** It researches,
> drafts, and exports. You decide what (if anything) gets sent, using your
> own email/LinkedIn tools.

---

## 1. What SignalScout does

You give it:

- Your product/service, target customer, and target geography
- Up to 10 prospects (company, contact, and any "trigger evidence" you've
  already found — a funding announcement, a job posting, etc.)

It runs each prospect through four research/drafting stages:

1. **Signal Analyzer** — checks whether your trigger evidence actually
   supports a real signal (funding, hiring, expansion, etc.), or honestly
   reports "No verified signal" if it doesn't.
2. **Company Context Analyzer** — summarizes what's known, separating facts
   from hypotheses.
3. **Outreach Strategist** — recommends an angle, or recommends
   **"Do not contact yet"** if there's nothing solid to go on.
4. **Personalized Copywriter** — drafts an email, a LinkedIn message, and a
   follow-up — grounded only in the evidence you gave it.

You then review every draft, edit it if needed, mark it
PENDING / APPROVED / REJECTED / EDIT REQUIRED, and export the results to CSV
or JSON.

## 2. Features

- Works fully offline in **Demo Mode** — no API key needed, ever.
- Optional OpenAI or Anthropic support via your own API key.
- Manual prospect entry (editable table) or CSV upload, max 10 per run.
- Never invents facts: if evidence is missing, it says so instead of guessing.
- One failed prospect never crashes the batch — it's marked `FAILED` with the
  error preserved, and the rest still process.
- Human-in-the-loop approval workflow before anything leaves the app.
- Export to CSV (stable columns, ready for Make.com / Tableau) and JSON.

## 3. Project structure

```
signal_scout/
├── app.py                     # Streamlit UI
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── core/
│   ├── ai_client.py            # Provider-agnostic AI call wrapper
│   ├── signal_analyzer.py      # Stage 1
│   ├── context_analyzer.py     # Stage 2
│   ├── outreach_strategist.py  # Stage 3
│   ├── copywriter.py           # Stage 4
│   └── pipeline.py             # Orchestrates all 4 stages per prospect
├── prompts/
│   ├── signal_analyzer.txt
│   ├── context_analyzer.txt
│   ├── outreach_strategist.txt
│   └── copywriter.txt
├── data/
│   ├── prospects_template.csv  # Blank example you can fill in
│   └── outputs/                 # (empty — for your own exports if you want)
└── utils/
    ├── csv_handler.py
    └── validators.py
```

## 4. How to install Python dependencies

You'll need Python 3.9+.

```bash
python -m venv .venv
```

**Windows:**
```bash
.venv\Scripts\activate
```

**Mac/Linux:**
```bash
source .venv/bin/activate
```

Then install dependencies:
```bash
pip install -r requirements.txt
```

## 5. How to run locally

```bash
streamlit run app.py
```

This opens SignalScout in your browser, usually at `http://localhost:8501`.

## 6. How Demo Mode works

Demo Mode is selected by default and needs **no API key**. Instead of calling
an external AI model, it generates deterministic mock responses based only on
what you typed into "Trigger Evidence URL / Notes" — it looks for keywords
(e.g. "funding", "hiring", "launch") to classify a plausible signal type, and
clearly labels every field `[DEMO MODE]`. If you leave trigger evidence blank,
it will honestly report "No verified signal" — it does not invent one.

Use Demo Mode to try out the whole workflow (input → analysis → approval →
export) before connecting a real AI provider.

## 7. How to add an OpenAI API key

1. Get a key from https://platform.openai.com/api-keys
2. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
3. Open `.env` and set:
   ```
   OPENAI_API_KEY=sk-...
   ```
4. Restart the app and select **OpenAI** in the sidebar.

## 8. How to add an Anthropic API key

1. Get a key from https://console.anthropic.com/
2. In your `.env` file, set:
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   ```
3. Restart the app and select **Anthropic** in the sidebar.

Your `.env` file is listed in `.gitignore` and is never committed or shown in
the UI.

## 9. Example CSV format

See `data/prospects_template.csv`, or download it from inside the app
("Download blank CSV template"). Columns:

```
Prospect ID, Company, Website, Contact, Job Title, LinkedIn URL,
Trigger Evidence URL, Trigger Evidence/Notes
```

Only **Company** is required. Everything else can be left blank — but the
more trigger evidence you provide, the stronger a signal SignalScout can
verify.

## 10. How to export results

After running analysis and reviewing/approving prospects, use the buttons in
the **Export** section:

- **Export All Results (CSV)** — every processed prospect, any status.
- **Export Approved Only (CSV)** — only prospects marked `APPROVED`.
- **Download JSON** — the complete structured results, including all four
  stages' full output, for your own scripting/automation.

## 11. How to connect the CSV to Make.com

The export CSV has **stable column names** designed for Make.com scenarios.
The local app does not connect to Make.com directly — you move the CSV (or
automate the whole pipeline in Make.com itself) by hand.

**Make Scenario 1 — Research pipeline:**
```
Google Sheets (prospect list)
  → Signal Analysis (HTTP/OpenAI/Anthropic module)
  → Company Context
  → Outreach Strategy
  → Personalized Copy
  → Google Sheets (write results back, matching the export column names)
```

**Make Scenario 2 — Approved-only export:**
```
Google Sheets (results)
  → Filter: Approval Status = APPROVED
  → Approved Export (e.g. to your CRM or email tool)
```

Because column names stay fixed release to release, you can build these
scenarios once and re-import new SignalScout CSVs without remapping fields.

## 12. How to connect the CSV to Tableau

The export CSV avoids nested JSON — every field is a flat string column — so
you can connect it directly as a **Text File** data source in Tableau. Useful
columns for dashboards:

- `Signal Type`, `Signal Strength`
- `Approval Status`
- `Geography`, `Company`
- Combine `Signal Strength` + `Approval Status` for a simple funnel view of
  how many verified-signal prospects made it to approval.

## 13. Limitations

- Demo Mode is a **mock**, not a real AI — its "analysis" is keyword
  matching on the text you supply, nothing more.
- SignalScout does not scrape the web, LinkedIn, or any other site. It only
  reasons over the trigger evidence you paste in yourself.
- Real AI providers (OpenAI/Anthropic) can occasionally return malformed
  JSON; SignalScout catches this per-stage and marks that prospect
  `FAILED`/`PARTIAL` rather than crashing, but you may need to re-run it.
- This is a V1 portfolio prototype — there's no database, no multi-user
  support, and no persistence between app restarts beyond what you export.

## 14. Future improvements

- Optional lightweight web-fetch (with explicit user consent per URL) to
  verify trigger evidence pages exist, rather than trusting notes alone.
- Save/load past runs to local JSON files instead of only exporting.
- Direct Make.com webhook trigger from the Export section.
- Multi-language outreach copy.
- Bulk CSV editing UI for large batches (still capped, but with pagination).
